 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loadbalancer1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dushk
 */
public class Server extends Thread {
    
    int port;
    InetAddress addr;
    NodeManager1 nMgr;
    
    
    public Server() {
        this.nMgr = new NodeManager1();/*this= current object, whose method is being called upon.
        calls the node manager*/
    }
    
    public void run() {
        try {
            DatagramSocket socket = new DatagramSocket(5000, InetAddress.getByName("192.168.1.38"));/*sets the IP address*/
            socket.setSoTimeout(0);/*closes the socket*/
            
            boolean server = true;/*if its true then it will run the while statement below*/
            while (server) {
                byte[] packetData = new byte[1024];/*gets 1024 bytes from teh packet data*/
                DatagramPacket packet = new DatagramPacket(packetData, packetData.length);/*gets the length of the packet data
                from the datagram packet*/
                
                socket.receive(packet);/*receives the data from the packet*/
                String message = new String(packetData);/*sets a variable and gets the string packet data*/
                System.out.println("------------------------------------");
                System.out.println("Got Data: " + message);/*displays the message*/
                
                String[] cmds = message.trim().split("/");/*cmds= core minimum data set. sets the minimum
                data for the message and then trims the whitespace of a string and then split it*/
                
                switch (cmds[0]) {/*gets the element 0 from the arguments list*/
                    /*creates a reg message*/
                    case "REG": {
                        nMgr.addNode(cmds[1], packet.getAddress(), packet.getPort(), Integer.parseInt(cmds[2]));/*this is a registration
                        message in which adds the node from the element 1 on the arguments list (port number), it then gets
                        the IP address, port number and parses the integer element of the argument list.*/
                        break;/*stops*/
                    }/*----------------------------------------------------*/
                    
                    /*creates a job message*/
                    case "JOB": {
                        int jobSize = Integer.parseInt(cmds[1]);/*the integer variable "jobSize" gets the argument from the args list*/
                        String jobName = cmds[2];/*job name is the minimum data set from the 2nd argument*/
                        
                        
                        System.out.println("Got Job: " + jobName + " " + jobSize);/*prints the job name and size*/
                        
                        Node1 node = nMgr.getNextNode();/*gets the next node function*/
                        System.out.println(node.getNodeName() + " " + node.getNodeAddress() + " " + node.getNodePort());/*gets and prints
                        the node name, address and port by suing the "get" function*/
                        node.sendMessage("JOB/" + jobName + "/" + jobSize);/*sents the message with the elements 
                        within the brackets*/
                        System.out.println("------------------------------------");
                        break;
                    }/*--------------------------------------------------*/
                }
            }
            
            /*Error checker*/
            /*Socket error*/
        } catch (SocketException ex) {
            Logger.getLogger(LoadBalancer1.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(0);
            /*----------------------------------------------------------------------*/
            /*Input/ Output errors*/
        } catch (IOException ex) {
            Logger.getLogger(LoadBalancer1.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error");/*shows error if the input or output is wront*/
        }/*---------------------------------------------------------*/
    }
    
}
